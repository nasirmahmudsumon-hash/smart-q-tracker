# SMART Q Tracker — Web Application Starter (Android-friendly deployment scaffold)

Developed by Abdullah Al Nasir

## এখন কী কাজ করে
- বর্তমান SMART Q Tracker HTML Node.js server থেকে পরিবেশন হয়।
- Login, account request, GM Quality approval/rejection server API-তে যুক্ত করা হয়েছে।
- Account request ও account server-এর `data/accounts.json`-এ থাকে; password Node.js `scrypt` hash হিসেবে সংরক্ষিত হয়।
- Session cookie HttpOnly ও SameSite=Lax; production mode-এ Secure flag যোগ হয়।
- Public health endpoint: `/api/health`।

## লোকাল পরীক্ষা
1. Node.js 18 বা পরের সংস্করণ ইনস্টল থাকা কম্পিউটারে ZIP extract করুন।
2. ফোল্ডারে terminal খুলে `npm start` চালান।
3. `http://localhost:3000` খুলুন।
4. প্রথমবার তৈরি হওয়া GM Quality account: `gm` / `demo123`। শুধুমাত্র লোকাল পরীক্ষায় ব্যবহার করুন। Public hosting-এর আগে শক্তিশালী `GM_PASSWORD` সেট করে প্রথমবার account database তৈরি হওয়ার আগেই ব্যবহার করতে হবে; database তৈরি হয়ে গেলে password পরিবর্তনের জন্য আলাদা admin/password-reset workflow প্রয়োজন।

## Android ফোন থেকে অনলাইনে deploy
এই ZIP নিজে থেকে public website তৈরি করে না। Android Chrome দিয়ে কোনো Node.js hosting provider-এর dashboard-এ repository/ZIP থেকে app deploy করতে হবে। Provider-এর বর্তমান deploy পদ্ধতি ও persistent storage support আগে যাচাই করতে হবে। Hosting-এ HTTPS ও persistent disk/database আবশ্যক; temporary filesystem-এ `accounts.json` রাখলে restart/deploy-এর পর account data হারাতে পারে।

## গুরুত্বপূর্ণ সীমাবদ্ধতা — এখনও production-ready নয়
- Login/account request/approval server API-তে যুক্ত; কিন্তু inspection, CAPA, Fabric Inspection, Digital Check Sheet ও অন্যান্য QMS business records এখনও browser `localStorage`-এ থাকে। তাই একাধিক ফোনে QMS data sync হয় না।
- User/role permission-এর বর্তমান frontend আচরণ পূর্ণ server-side authorization নয়; sensitive data public deployment-এ দেওয়ার আগে role enforcement server-side করতে হবে।
- এটি experimental scaffold। Production-এর আগে persistent database, secure admin bootstrap/password reset, rate limiting, CSRF protection, strict security headers/CSP, audit logging, backup/restore, server-side validation/authorization, privacy review এবং security testing প্রয়োজন।
- বাস্তব factory/buyer data আপাতত দেবেন না। এটি ISO certification বা factory conformity প্রমাণ করে না।
