const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const PORT = process.env.PORT || 3000;
const HOST = process.env.HOST || '0.0.0.0';
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'accounts.json');
const PUBLIC_DIR = path.join(__dirname, 'public');
fs.mkdirSync(DATA_DIR, { recursive: true });
const hash = (p,s) => crypto.scryptSync(p,s,64).toString('hex');
const safeEq = (a,b) => { try { return crypto.timingSafeEqual(Buffer.from(a,'hex'),Buffer.from(b,'hex')); } catch { return false; } };
function load(){ try { return JSON.parse(fs.readFileSync(DB_FILE,'utf8')); } catch { const salt=crypto.randomBytes(16).toString('hex'); const db={users:[{id:crypto.randomUUID(),name:'GM Quality',username:'gm',salt,hash:hash(process.env.GM_PASSWORD || 'demo123',salt),role:'GM Quality',status:'approved',createdAt:new Date().toISOString()}],sessions:[],requests:[]}; save(db); return db; } }
function save(db){ fs.writeFileSync(DB_FILE, JSON.stringify(db,null,2), {mode:0o600}); }
let db=load();
const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json'};
function send(res,status,obj){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(JSON.stringify(obj));}
function body(req){return new Promise((resolve,reject)=>{let d='';req.on('data',c=>{d+=c;if(d.length>100000)req.destroy();});req.on('end',()=>{try{resolve(d?JSON.parse(d):{});}catch{reject(new Error('Invalid JSON'));}});});}
function tokenFrom(req){const m=(req.headers.cookie||'').match(/sqt_session=([^;]+)/);return m?decodeURIComponent(m[1]):'';}
function current(req){const t=tokenFrom(req);const s=db.sessions.find(x=>x.token===t&&x.expires>Date.now());return s?db.users.find(u=>u.id===s.userId&&u.status==='approved'):null;}
function publicUser(u){return {id:u.id,name:u.name,username:u.username,role:u.role,status:u.status};}
const server=http.createServer(async(req,res)=>{
 try{
  const url=new URL(req.url,'http://localhost');
  if(req.method==='GET'&&url.pathname==='/api/health') return send(res,200,{ok:true,app:'SMART Q Tracker Web App Starter',time:new Date().toISOString(),note:'Account API is shared on this server. Main QMS module records still use browser storage until migrated to server database.'});
  if(req.method==='POST'&&url.pathname==='/api/register'){
   const b=await body(req);const username=String(b.username||'').trim().toLowerCase();const password=String(b.password||'');
   const allowedRoles=['Quality Manager','Line Supervisor','Line QC','Store / Fabric QC','Production','Buyer'];
   if(!/^[a-z0-9._-]{3,32}$/.test(username)||password.length<8||String(b.name||'').trim().length<2) return send(res,400,{error:'Enter a name, username (3–32 allowed characters) and password (at least 8 characters).'});
   if(!allowedRoles.includes(String(b.role||'Line QC'))) return send(res,400,{error:'Requested role is not allowed. GM Quality accounts cannot be self-requested.'});
   if(db.users.some(u=>u.username===username)||db.requests.some(r=>r.username===username&&r.status==='pending'))return send(res,409,{error:'Username already exists or is awaiting approval.'});
   const salt=crypto.randomBytes(16).toString('hex');db.requests.push({id:crypto.randomUUID(),name:String(b.name).trim().slice(0,80),username,salt,hash:hash(password,salt),department:String(b.department||'').slice(0,80),role:String(b.role||'Line QC').slice(0,40),reason:String(b.reason||'').slice(0,500),status:'pending',createdAt:new Date().toISOString()});save(db);return send(res,201,{ok:true,message:'Request submitted. GM approval is required before sign in.'});
  }
  if(req.method==='POST'&&url.pathname==='/api/login'){
   const b=await body(req);const username=String(b.username||'').toLowerCase();const u=db.users.find(x=>x.username===username);
   if(!u||u.status!=='approved'||!safeEq(hash(String(b.password||''),u.salt),u.hash))return send(res,401,{error:'Invalid credentials or account not approved.'});
   const token=crypto.randomBytes(32).toString('hex');db.sessions=db.sessions.filter(s=>s.expires>Date.now());db.sessions.push({token,userId:u.id,expires:Date.now()+8*60*60*1000});save(db);res.writeHead(200,{'Content-Type':'application/json','Set-Cookie':`sqt_session=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=28800${process.env.NODE_ENV==='production'?'; Secure':''}`,'Cache-Control':'no-store'});return res.end(JSON.stringify({ok:true,user:publicUser(u)}));
  }
  if(req.method==='POST'&&url.pathname==='/api/logout'){const t=tokenFrom(req);db.sessions=db.sessions.filter(s=>s.token!==t);save(db);res.writeHead(200,{'Content-Type':'application/json','Set-Cookie':`sqt_session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0${process.env.NODE_ENV==='production'?'; Secure':''}`});return res.end('{"ok":true}');}
  if(url.pathname.startsWith('/api/')){
   const u=current(req);if(!u)return send(res,401,{error:'Sign in required.'});
   if(req.method==='GET'&&url.pathname==='/api/me')return send(res,200,{user:publicUser(u)});
   if(req.method==='GET'&&url.pathname==='/api/requests') {if(u.role!=='GM Quality')return send(res,403,{error:'GM Quality approval permission required.'});return send(res,200,{requests:db.requests.filter(r=>r.status==='pending').map(({hash,salt,...r})=>r)});}
   const m=url.pathname.match(/^\/api\/requests\/([\w-]+)\/(approve|reject)$/);if(req.method==='POST'&&m){if(u.role!=='GM Quality')return send(res,403,{error:'GM Quality approval permission required.'});const r=db.requests.find(x=>x.id===m[1]&&x.status==='pending');if(!r)return send(res,404,{error:'Pending request not found.'});if(m[2]==='approve'){db.users.push({id:crypto.randomUUID(),name:r.name,username:r.username,salt:r.salt,hash:r.hash,role:r.role,status:'approved',department:r.department,createdAt:new Date().toISOString(),approvedBy:u.username});r.status='approved';r.approvedBy=u.username;r.approvedAt=new Date().toISOString();}else{r.status='rejected';r.approvedBy=u.username;r.approvedAt=new Date().toISOString();}save(db);return send(res,200,{ok:true,status:r.status});}
   return send(res,404,{error:'API route not found.'});
  }
  let p=url.pathname==='/'?'/index.html':decodeURIComponent(url.pathname);p=path.normalize(p).replace(/^([.][.][/\\])+/, '');const file=path.join(PUBLIC_DIR,p);if(!file.startsWith(PUBLIC_DIR))return send(res,403,{error:'Forbidden'});fs.readFile(file,(err,data)=>{if(err)return send(res,404,{error:'File not found'});res.writeHead(200,{'Content-Type':mime[path.extname(file)]||'application/octet-stream','X-Content-Type-Options':'nosniff'});res.end(data);});
 }catch(e){send(res,400,{error:'Request could not be processed.'});}
});
server.listen(PORT,HOST,()=>console.log(`SMART Q Tracker web starter running at http://localhost:${PORT}`));
